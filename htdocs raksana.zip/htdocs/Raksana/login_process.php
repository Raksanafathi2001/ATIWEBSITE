<?php
session_start();

// Database connection (similar to register.php)
// ... (connection code)

$email = $_POST['email'];
$password = $_POST['password'];

$select_query = "SELECT * FROM Lecturer WHERE Email='$email'";
$result = $conn->query($select_query);

if ($result->num_rows == 1) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['Password'])) {
        $_SESSION['email'] = $email;
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Incorrect password";
    }
} else {
    echo "User not found";
}

$conn->close();
?>
