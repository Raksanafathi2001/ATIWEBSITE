<?php
session_start();

if(isset($_SESSION['email'])) {
    header("Location: dashboard.php");
    exit();
}
?>

<!-- HTML form for lecturer login -->
<form action="login_process.php" method="post">
    <input type="email" name="email" placeholder="Email" required><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <input type="submit" value="Login">
</form>
