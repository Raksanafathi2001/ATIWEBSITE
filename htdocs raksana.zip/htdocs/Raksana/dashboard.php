<?php
session_start();

if(!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['email'];
?>

<!-- Display logged-in lecturer's email -->
Logged in as: <?php echo $email; ?>

<!-- Add functionalities for the dashboard -->
<!-- ... -->
