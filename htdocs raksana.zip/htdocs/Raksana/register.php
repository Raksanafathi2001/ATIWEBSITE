<?php
// Database connection
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "ATIWEB";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch courses from the Course table
$courses_query = "SELECT * FROM Course";
$courses_result = $conn->query($courses_query);
?>

<!-- HTML form for lecturer registration -->
<form action="register_process.php" method="post">
    <input type="text" name="name" placeholder="Name in full" required><br>
    <input type="email" name="email" placeholder="Email" required><br>
    <select name="designation" required>
        <option value="">Select Designation</option>
        <option value="Assistant Lecturer">Assistant Lecturer</option>
        <option value="Lecturer">Lecturer</option>
        <option value="Senior Lecturer I">Senior Lecturer I</option>
        <option value="Senior Lecturer II">Senior Lecturer II</option>
    </select><br>
    <select name="course" required>
        <option value="">Select Course</option>
        <?php
        if ($courses_result->num_rows > 0) {
            while ($row = $courses_result->fetch_assoc()) {
                echo "<option value='" . $row['CourseID'] . "'>" . $row['Title'] . "</option>";
            }
        }
        ?>
    </select><br>
    <select name="gender" required>
        <option value="">Select Gender</option>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
    </select><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <input type="submit" value="Register">
</form>
<?php
$conn->close();
?>
