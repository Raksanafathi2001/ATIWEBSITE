CREATE TABLE IF NOT EXISTS Lecturer (
    LecID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100),
    Email VARCHAR(100) UNIQUE,
    Designation ENUM('Assistant Lecturer', 'Lecturer', 'Senior Lecturer I', 'Senior Lecturer II'),
    CourseID INT,
    Gender ENUM('Male', 'Female'),
    Password VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS Course (
    CourseID INT AUTO_INCREMENT PRIMARY KEY,
    Title VARCHAR(100),
    TitleInShort VARCHAR(50),
    Description TEXT
);
