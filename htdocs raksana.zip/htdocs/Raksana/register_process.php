<?php
// Database connection (similar to register.php)
// ... (connection code)

// Retrieve form data
$name = $_POST['name'];
$email = $_POST['email'];
$designation = $_POST['designation'];
$courseID = $_POST['course'];
$gender = $_POST['gender'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password

// Insert data into Lecturer table
$insert_query = "INSERT INTO Lecturer (Name, Email, Designation, CourseID, Gender, Password)
                 VALUES ('$name', '$email', '$designation', '$courseID', '$gender', '$password')";

if ($conn->query($insert_query) === TRUE) {
    echo "Registration successful!";
} else {
    echo "Error: " . $insert_query . "<br>" . $conn->error;
}

$conn->close();
?>
